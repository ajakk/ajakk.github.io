#! /bin/sh -f
exec /usr/bin/djvuserve
